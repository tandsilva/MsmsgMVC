package com.ms.email.enums;

public enum StatusEmail {
    PROCESSING,
    SENT,
    ERROR;
}
